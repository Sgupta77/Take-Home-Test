function showTextFunction() {
    // Get all the elements
    let dots = document.getElementById("dots");

    let showMoreText = document.getElementById("show-more-text");

    let showMoreCtaText = document.getElementById("showmorecta");

    if (dots.style.display === "none") {

        // Hide the text between the span dots
        showMoreText.style.display = "none";

        // Show the dots after the text
        dots.style.display = "inline";

        // Change the text on button to 'Show More'
        showMoreCtaText.innerHTML = "Show More";

    } else {
        showMoreText.style.display = "inline";

        // Hide the dots after the text
        dots.style.display = "none";

        // Change the text on button to 'Show Less'
        showMoreCtaText.innerHTML = "Show Less";
    }
}